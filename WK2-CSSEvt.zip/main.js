window.onload = () => {
  /* adjust CSS animation */





  /* select the block to show */



};
